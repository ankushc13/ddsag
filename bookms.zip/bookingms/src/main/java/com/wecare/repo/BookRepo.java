package com.wecare.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wecare.entity.BookEntity;
@Repository
public interface BookRepo extends JpaRepository<BookEntity, Integer>{

	List<BookEntity> findByCoachId(Integer CoachId);
	List<BookEntity> findByUserId(Integer UserId);
	Optional<BookEntity> findByBookingId(Integer bookingId);

}
