package com.wecare.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wecare.DTO.AppointDTO;
import com.wecare.DTO.BookDTO;
import com.wecare.DTO.CoachDTO;
import com.wecare.DTO.LoginDTO;
import com.wecare.entity.BookEntity;
import com.wecare.repo.BookRepo;


@Service
public class BookService {
	@Autowired
	BookRepo bookRepo;
	
	public Boolean bookAppointment(Integer userId,Integer coachId,AppointDTO appointDTO) {
		BookDTO bookDTO=new BookDTO();
		bookDTO.setAppointmentDate(appointDTO.getAppointmentDate());
		bookDTO.setCoachId(coachId);
		bookDTO.setUserId(userId);
		bookDTO.setSlot(appointDTO.getSlot());
		BookEntity en=BookDTO.change(bookDTO);
		bookRepo.saveAndFlush(en);
		return true;
	}
	public List<BookDTO> getCoachBook(Integer id){
		
		List<BookEntity> ents=bookRepo.findByCoachId(id);
		List<BookDTO> dto=new ArrayList<>();
		for(BookEntity ent:ents) {
			dto.add(BookDTO.changeTo(ent));
		}
		return dto;
	
	}
	public List<BookDTO> getUserBook(Integer id){
		List<BookEntity> ents=bookRepo.findByUserId(id);
		List<BookDTO> dto=new ArrayList<>();
		for(BookEntity ent:ents) {
			dto.add(BookDTO.changeTo(ent));
		}
		return dto;
	}
	public Boolean rescheduleAppointment(Integer id,AppointDTO appointDTO) {
		Optional<BookEntity> oEn=bookRepo.findByBookingId(id);
		if(oEn.isPresent()) {
			BookEntity entity=oEn.get();
			entity.setAppointmentDate(appointDTO.getAppointmentDate());
			entity.setSlot(appointDTO.getSlot());
			bookRepo.saveAndFlush(entity);
			return true;
		}
		return false;
	}
	public void cancelAppointment(Integer id) {
		bookRepo.deleteById(id);
	}
	
	
}
